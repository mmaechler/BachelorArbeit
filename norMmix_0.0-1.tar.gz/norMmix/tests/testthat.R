library(testthat)
library(norMmix)

test_check("norMmix")

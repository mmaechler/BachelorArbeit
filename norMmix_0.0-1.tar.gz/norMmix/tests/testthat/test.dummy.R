context("dummy test")

test_that("this is a dummy",{
    expect_equal(2+2,4)})
